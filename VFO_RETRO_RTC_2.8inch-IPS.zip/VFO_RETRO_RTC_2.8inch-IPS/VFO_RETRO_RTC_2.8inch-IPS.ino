/* 
  ESP32 Digital VFO with Rotation Dial covering 100kHz to 30MHz, OCXO and RTC
  While some of the parts used are specialized, none are expensive.
  Based on:
  
    File:   VFOsys2.ino
    Author: JF3HZB / T.UEBO
 
    Created on July 1, 2023
*/

/*
  AC9NM Updated as of June 2026:
  Board manager: esp32 ver. 3.3.10
  Arduino IDE 2.3.10
  Board: DOIT ESP32 Devkit V1 Module (30-pin) or NodeMCU-32S (30-pin)
  Library: LovyanGFX ver. 1.2.24
  Kicad 10.x PCB Layout & Gerbers
  KY040 Rotary Encoder
  ST7789 IPS 1,9" display 170x320 and 0.91 inch OLED for clock
  CTI OSC5A2B02 10 MHz Oven Controled Xtal Oscillator (OCXO)
  Si5351A Clock generator IC (TSSOP-8)
  74LVC1G04DBVR single inverter gate (SOT23-5 package)
  ICS511 or ICS501 frequency multiplier IC (SOIC-8)
  DS3231N Real Time Clock (RTC) module

  Note: Make sure that lines 38 and 39 in si5351.h file has the correct address for your Si5351A
  and crystal frequency.
  
  All outputs are at the same frequency. CLK2 can be enabled/disabled with setting carON on line 161.
  Quadrature outputs are on CLK0 and CLK1. CLK0 leads CLK1.
  The Si5351A CLK2 is inverted in relation to CLK0 for frequencies 3.2MHz or higher. 
  The Si5351A CLK2 is inverted in relation to CLK1 for frequencies below 3.2MHz. 

  Since the Si5351A's outputs are buffered, setting the Si5351 drive levels has no effect on the
  buffered outputs levels.
  
  The DS3231N Real Time Clock module (RTC) is set by a NTP server over WiFi. Therefore, the module does
  not need a battery. The WiFi is turned off after the time is set but you can just leave it on 
  if you wish by commenting out lines 566-568. Set up your ssid and password on lines 99 and 100. 
  The RTC uses I2C addresses 0x57 and 0x68. NTP Client Setup for UTC is on line 10.
  If you don't install the RTC, the time is simply not displayed.

  The DACs are connected to a JST jack so that they can be used with Tayloe type QSE/QSDs for I/Q Balance,
  0 - 3.2V output.

  Partial CAT Control Kenwood ST-2000 Emulation, 9600 BAUD, by Barb (Barbaros ASUROGLU) - WB2CBA.
____________________________________________________________________________________________________
  GPIO pins used for rotary encoder
  CLK 17
  DT  16

  GPIO pins used for push buttons:
  STORE 32 // Save current frequency as power up frequency
  MEMORY_CH 13 // Step through bands
  STEP_PLUS 14
  STEP_MINUS 27
  LIMIT 33 // Limit frequency range to HAM band

  GPIO pins used by display:
  SCLK  18
  SDA/MOSI 23
  DC  2
  CS  5
  RST 15

  GPIO pins used for PTT & TX/RX
  TX 19
  PTT 4

  GPIO pins used for Si5351A
  SDA 21
  SCL 22

  GPIO pins used for DAC 
  LBAL 25
  RBAL 26
*/

#define NAME "VFO System"
#define VERSION "Ver. 2.00"
#define ID "by JF3HZB"

#include <Arduino.h>
#include "dial.hpp"       // Display layout
#include "si5351.h"       // JF3HZB / T.UEBO si5351A programming routines
#include <ESP32Encoder.h> // https://github.com/madhephaestus/ESP32Encoder.git 
#include <Preferences.h>  // ESP32 storage system used in place of EEPROM, etc.
#include "VFO_defs.h"     // PIN defintions
#include <Button.h>       // ESP32 Push button library https://github.com/esp-arduino-libs/ESP32_Button.git
#include <Preferences.h>  // ESP32 storage system used in place of EEPROM, etc.
#include <WiFi.h>
#include <NTPClient.h>
#include <WiFiUdp.h>
#include <MKL_RTClib.h>
#include <cstring>

// Wi-Fi Credentials
const char* ssid     = "linksys";
const char* password = "onyxlee123onyxlee234!!!@@@###$$$";

// NTP Client Setup for UTC. Change 0 below to your timezone offset in seconds. The 60000 reprsents the update interval in ms (1 minute).
WiFiUDP ntpUDP; // For example, CDT would be -18000, 60000); Also, change the UTC on line 636 to the TLA for your timezone.
NTPClient timeClient(ntpUDP, "pool.ntp.org", 0, 0);  

// I/Q Balance DAC 
#define LBAL_PIN 25 // GPIO pin for Right Balance
#define RBAL_PIN 26 // GPIO pin for Left Balance

RTC_DS3231 rtc;

band_data bandData[] = // See VFO_defs for more info.
{
// |    vfo   |  lowLimit  |  topLimit  | opMode
  {  1800000UL,  1800000UL,  2000000UL, MODE_LSB },
	{  3500000UL,  3500000UL,  4000000UL, MODE_LSB },
	{  7000000UL,  7000000UL,  7300000UL, MODE_LSB },
  { 10100000UL, 10100000UL, 10150000UL, MODE_USB },
	{ 14000000UL, 14000000UL, 14350000UL, MODE_USB },
  { 18068000UL, 18068000UL, 18168000UL, MODE_USB },
	{ 21000000UL, 21000000UL, 21450000UL, MODE_USB },
	{ 24890000UL, 24890000UL, 24990000UL, MODE_USB },
  { 28000000UL, 28000000UL, 29700000UL, MODE_USB },
  {  4900000UL,  4900000UL,  5500000UL, MODE_LSB }  //Kenwood TS-520 VFO Range
};

volatile long newPosition = 0;
volatile long oldPosition = 0;
volatile int32_t step;
bool bal = true;
int val=0;  // DAC test value

ESP32Encoder encoder;
Preferences preferences;
Si5351 si5351;

LGFX lcd;
LGFX_Sprite sp;
LGFX_Sprite sprites[2];
bool flip;
int sprite_height; 
DIAL dial; // Rotating dial instance
uint32_t phaseDelay;

/*-------------------------------------------------------
   Frequency settings
--------------------------------------------------------*/
volatile uint32_t Dial_frq;   // Si5351A quadrature frequency
volatile int Even_Divisor;
volatile int oldEven_Divisor = 0;
volatile float readParam;
volatile bool Limit = true; // Limit VFO to HAM bands = true
volatile uint8_t activeBand;	// Index into bandData array (representing the current band)
uint32_t incrList[7] = { 1, 10, 100, 1000, 10000, 100000, 1000000 };	// freq change increments
uint8_t Hz = 0;

/*----------------------------------------------------------------------------------
    Control flags
-----------------------------------------------------------------------------------*/
uint8_t f_fchange = 1;    // if quadrature frequency changed, set this flag to 1
uint8_t f_carON = 1;      // ON(1)/OFF(0) Car signal

/*----------------------------------------------------------------------------------
   CAT Variables
-----------------------------------------------------------------------------------*/
boolean cat_stat = 0;
boolean TxStatus = 0; //0 = RX 1 = TX
unsigned int CAT_mode;
String received;
String receivedPart1;
String receivedPart2;
String command;
String command2;
String parameter;
String parameter2;
String sent;
String sent2;

/*-----------------------------------------------------------------------------
         Global
-----------------------------------------------------------------------------*/ 
int cnt = 2; // step index 
long mem, mem_old;
int cnt_old;
char str[64];
int ptt_btn;
int tx_state;
char buffer[100];
bool rtc_found = false; // Is RTC found flag
/*--------------------------------------------------------------------------
      Si5351 Quadrature Configuration
---------------------------------------------------------------------------*/
void EvenDivisor()
{
  if (Dial_frq < 100000)
    Even_Divisor = 8192;

  if ((Dial_frq >= 100000) && (Dial_frq < 200000))
    Even_Divisor = 4096;

  if ((Dial_frq >= 200000) && (Dial_frq < 400000))
    Even_Divisor = 2048;

  if ((Dial_frq >= 400000) && (Dial_frq < 800000))
    Even_Divisor = 1024;

  if ((Dial_frq >= 800000) && (Dial_frq < 1600000))
    Even_Divisor = 512;

  if ((Dial_frq >= 1600000) && (Dial_frq < 3200000))
    Even_Divisor = 256;

// Use Time Delay Phasing when Even_Divisor > 126

  if ((Dial_frq >= 3200000) && (Dial_frq < 6850000))
    Even_Divisor = 126;

  if ((Dial_frq >= 6850000) && (Dial_frq < 9500000))
    Even_Divisor = 88;

  if ((Dial_frq >= 9500000) && (Dial_frq < 13600000))
    Even_Divisor = 64;

  if ((Dial_frq >= 13600000) && (Dial_frq < 17500000))
    Even_Divisor = 44;

  if ((Dial_frq >= 17500000) && (Dial_frq < 25000000))
    Even_Divisor = 34;

  if ((Dial_frq>= 25000000) && (Dial_frq< 36000000))
    Even_Divisor = 24;

  if ((Dial_frq >= 36000000) && (Dial_frq < 45000000))
    Even_Divisor = 18;

  if ((Dial_frq >= 45000000) && (Dial_frq < 60000000))
    Even_Divisor = 14;

  if ((Dial_frq >= 60000000) && (Dial_frq < 80000000))
    Even_Divisor = 10;

  if ((Dial_frq >= 80000000) && (Dial_frq < 100000000)) 
    Even_Divisor = 8;

  if ((Dial_frq >= 100000000) && (Dial_frq < 146600000))
    Even_Divisor = 6;

  if ((Dial_frq >= 150000000) && (Dial_frq < 220000000))
    Even_Divisor = 4;
}


/*--------------------------------------------------------------------------
 Phase delay lookup table values in microseconds for quadrature 
 outputs for frequencies between 3.2 MHz to 100 kHz <-H L->
--------------------------------------------------------------------------*/
void PhaseDelay ()
{
  if ((Dial_frq >= 100000) && (Dial_frq < 200000))
    phaseDelay = 59760;
  if ((Dial_frq >= 200000) && (Dial_frq < 300000))
    phaseDelay = 59960;
  if ((Dial_frq >= 300000) && (Dial_frq < 400000))
    phaseDelay = 60960;
  if ((Dial_frq >= 400000) && (Dial_frq < 500000))
    phaseDelay = 60160;
  if ((Dial_frq >= 500000) && (Dial_frq < 600000))
    phaseDelay = 60160;
  if ((Dial_frq >= 600000) && (Dial_frq < 700000))
    phaseDelay = 60160;
  if ((Dial_frq >= 700000) && (Dial_frq < 800000))
    phaseDelay = 60760;
  if ((Dial_frq >= 800000) && (Dial_frq < 900000))
    phaseDelay = 60360;
  if ((Dial_frq >= 900000) && (Dial_frq < 1000000))
    phaseDelay = 60560;

  if ((Dial_frq >= 1000000) && (Dial_frq < 2000000))
    phaseDelay = 60560;
  if ((Dial_frq >= 2000000) && (Dial_frq < 3000000))
    phaseDelay = 62460;
  if ((Dial_frq >= 3000000) && (Dial_frq < 3200000))
    phaseDelay = 63160;
  if ((Dial_frq >= 3200000))
    phaseDelay = 0;
  //Serial.print("phaseDelay: -- "); Serial.println(phaseDelay);
}


void SendFrequency()
{
  EvenDivisor();
  PhaseDelay();
  // Assuming you named your instance "si5351"
  uint64_t plla_frequency = si5351.plla_freq; 

  //Serial.print("PLLA Frequency (Hz): "); Serial.println(plla_frequency);

  if (Even_Divisor <= 126)
  {
    si5351.set_freq_manual(Dial_frq* SI5351_FREQ_MULT, Even_Divisor * Dial_frq* SI5351_FREQ_MULT, SI5351_CLK0);
    si5351.set_freq_manual(Dial_frq* SI5351_FREQ_MULT, Even_Divisor * Dial_frq* SI5351_FREQ_MULT, SI5351_CLK1);
    si5351.set_freq_manual(Dial_frq* SI5351_FREQ_MULT, Even_Divisor * Dial_frq* SI5351_FREQ_MULT, SI5351_CLK2);
    si5351.set_phase(SI5351_CLK0, 0);
    si5351.set_phase(SI5351_CLK1, Even_Divisor);
    si5351.set_ms_source(SI5351_CLK2, SI5351_PLLA);

    si5351.set_phase(SI5351_CLK2, 0);
    si5351.set_clock_invert(SI5351_CLK2, true);
    if(Even_Divisor != oldEven_Divisor) si5351.pll_reset(SI5351_PLLA);
    oldEven_Divisor = Even_Divisor;
  }
  else if(Even_Divisor > 126) 
  {
    //Serial.print("Even_Divisor: "); Serial.println(Even_Divisor);
    if (Dial_frq < 3200000) Hz = 4; // fix for loss of 90 degree phase below 3.2MHz
    si5351.set_freq_manual((Dial_frq - Hz) * SI5351_FREQ_MULT, Dial_frq* Even_Divisor * SI5351_FREQ_MULT, SI5351_CLK0);
    si5351.set_freq_manual((Dial_frq - Hz) * SI5351_FREQ_MULT, Dial_frq* Even_Divisor * SI5351_FREQ_MULT, SI5351_CLK1);
    si5351.set_ms_source(SI5351_CLK2, SI5351_PLLA);
    si5351.set_freq_manual((Dial_frq) * SI5351_FREQ_MULT, Dial_frq* Even_Divisor * SI5351_FREQ_MULT, SI5351_CLK2);

    si5351.set_phase(SI5351_CLK0, 0); // set phase registers to 0 just to be sure
    si5351.set_phase(SI5351_CLK1, 0);
    si5351.set_ms_source(SI5351_CLK2, SI5351_PLLA);
    si5351.set_phase(SI5351_CLK2, 0);

    si5351.pll_reset(SI5351_PLLA);
    si5351.set_freq_manual(Dial_frq* SI5351_FREQ_MULT, Dial_frq* Even_Divisor * SI5351_FREQ_MULT, SI5351_CLK1);
    //Serial.print("phaseDelay: "); Serial.println(phaseDelay);
    delayMicroseconds(phaseDelay); // adjust by trial and error.
    si5351.set_freq_manual(Dial_frq* SI5351_FREQ_MULT, Dial_frq* Even_Divisor * SI5351_FREQ_MULT, SI5351_CLK0);
    oldEven_Divisor = Even_Divisor;
  }
}


/*----------------------------------------------------------------------------------
    Push button callback functions
-----------------------------------------------------------------------------------*/

//////////////////////////////////    
// ptt button
//////////////////////////////////
static void onPTTPressedCb(void *button_handle, void *usr_data) {
    Serial.println("PTT closed");
    digitalWrite(TX, LOW);
    Serial.print("tx_out = ");Serial.println(digitalRead(TX));
}


static void onPTTReleasedCb(void *button_handle, void *usr_data) {
    Serial.println("PTT open");
    digitalWrite(TX, HIGH);
    Serial.print("tx_out = ");Serial.println(digitalRead(TX));
}


//////////////////////////////////
// limit (lock) button - GPIO 33
//////////////////////////////////
static void onLIMITPressedCb(void *button_handle, void *usr_data) {
    Serial.println("limit closed");
    Limit = !Limit;
    Serial.print("Limit = ");Serial.println(Limit);
}


static void onLIMITReleasedCb(void *button_handle, void *usr_data) {
    Serial.println("limit open");
}


///////////////////////////////////
// stepMinus - GPIO 27
///////////////////////////////////
static void onstepMinusPressedCb(void *button_handle, void *usr_data) {
    Serial.println("stepMinus closed");
    cnt--;
    if(cnt <= 0) cnt = 0;
    Serial.print("cnt = ");Serial.println(cnt);
}


static void onstepMinusReleasedCb(void *button_handle, void *usr_data) {
    Serial.println("stepMinus open");
}


//////////////////////////////////
// stepPlus - GPIO 14
//////////////////////////////////
static void onstepPlusPressedCb(void *button_handle, void *usr_data) {
    Serial.println("stepMinus closed");
    cnt++;
    if(cnt >= 5) cnt = 4;
    Serial.print("cnt = ");Serial.println(cnt);
}


static void onstepPlusReleasedCb(void *button_handle, void *usr_data) {
    Serial.println("stepMinus open");
}


//////////////////////////////////
// memoryCh - GPIO 13
//////////////////////////////////
static void onmemoryChPressedCb(void *button_handle, void *usr_data) {
    Serial.println("memoryCh closed");
    mem_old = mem;
    mem += 1;

    if( mem > 9 ) { mem =  0; }

    activeBand = mem;
    f_fchange=1;
    delay(300);
    Dial_frq = bandData[activeBand].lowLimit;	// Get the old receive frequency
    SendFrequency();
    Serial.print("Dial_frq = ");Serial.println(Dial_frq);
}


static void onmemoryChReleasedCb(void *button_handle, void *usr_data) {
    Serial.println("memoryCh open");
}


//////////////////////////////////
// store - GPIO 32
//////////////////////////////////
static void onstorePressedCb(void *button_handle, void *usr_data) {
    Serial.println("store closed");
    // Write frequency into preferences storage
    preferences.begin("my-app", false);
    long param = Dial_frq;
    preferences.putLong("param", Dial_frq);
    //Read it back
    Dial_frq = preferences.getLong("param", 0);
    preferences.end();
    delay(300);
    Serial.print("stored = ");Serial.println(Dial_frq);
}


static void onstoreReleasedCb(void *button_handle, void *usr_data) {
    Serial.println("store open");
}


void setup(void)
{
  Serial.begin ( 9600 );				// Start up the USB port
  Serial.setTimeout(4);
  Wire.begin();
  //Wire.setClock(400000); // Set to Fast-mode I2C (400 kHz)

  if (! rtc.begin()) {
    Serial.println("Couldn't find RTC");
    Serial.flush();
    rtc_found = false;
  } else {rtc_found = true;}

  //TX output pin
  pinMode(TX, OUTPUT); // TX control
  digitalWrite(TX, LOW);

  // PTT button state detection - GPIO 4
  Button *ptt_btn = new Button(GPIO_NUM_4, false);
  ptt_btn->attachPressDownEventCb(&onPTTPressedCb, NULL);
  ptt_btn->attachPressUpEventCb(&onPTTReleasedCb, NULL);

  // Limit button state detection
  Button *limit_btn = new Button(GPIO_NUM_33, false);
  limit_btn->attachPressDownEventCb(&onLIMITPressedCb, NULL);
  limit_btn->attachPressUpEventCb(&onLIMITReleasedCb, NULL);

  Button *stepMinus_btn = new Button(GPIO_NUM_27, false);
  stepMinus_btn->attachPressDownEventCb(&onstepMinusPressedCb, NULL);
  stepMinus_btn->attachPressUpEventCb(&onstepMinusReleasedCb, NULL);

  Button *stepPlus_btn = new Button(GPIO_NUM_14, false);
  stepPlus_btn->attachPressDownEventCb(&onstepPlusPressedCb, NULL);
  stepPlus_btn->attachPressUpEventCb(&onstepPlusReleasedCb, NULL);

  Button *memoryCh_btn = new Button(GPIO_NUM_13, false);
  memoryCh_btn->attachPressDownEventCb(&onmemoryChPressedCb, NULL);
  memoryCh_btn->attachPressUpEventCb(&onmemoryChReleasedCb, NULL);

  Button *store_btn = new Button(GPIO_NUM_32, false);
  store_btn->attachPressDownEventCb(&onstorePressedCb, NULL);
  store_btn->attachPressUpEventCb(&onstoreReleasedCb, NULL);
  
  //encoder.attachFullQuad( DT, CLK );
  encoder.attachHalfQuad( DT, CLK );
  encoder.setCount ( 0 );

  // Task0 on core 0 runs encoder tasks
  xTaskCreatePinnedToCore ( task0, "Task0", 4096, NULL, 1, NULL, 0 );

	activeBand = 0;		    // Default to first band

  LCD_setup();
  lcd.setTextColor(TFT_CYAN);
  lcd.setFont(&fonts::Font0);
  lcd.setTextSize(0.7f*( lcd.height()/64.0f));
  lcd.setCursor( 0.5f*(lcd.width()-lcd.textWidth(NAME) ), 0.3f*lcd.height() );
  lcd.printf( NAME );
  lcd.setTextSize(0.7*( lcd.height()/64.0f));
  lcd.setCursor( 0.5f*(lcd.width()-lcd.textWidth(VERSION) ), 0.4f*lcd.height());
  lcd.printf(VERSION); 
  lcd.setTextSize(0.7f*(lcd.height()/64.0f));
  lcd.setCursor( 0.5f*(lcd.width()-lcd.textWidth(ID) ), 0.5f*lcd.height());
  lcd.printf(ID);

  delay(1000);

  //Read the saved startup frequency
  preferences.begin("my-app", true);

  // Act like a Kenwood VFO-520S and read the saved startup freqency
  Dial_frq = preferences.getLong("param", 4900000);// Default startup frequency if none saved.

  // Find out which band Dial_frq is in
  for(int i=0;i<10;i++)
    {
    if ((Dial_frq >= bandData[i].lowLimit) && (Dial_frq <= bandData[i].topLimit))
      {
        mem = i;
        mem_old = i;
        activeBand = i;
        Serial.print("\nactiveBand ");Serial.println(activeBand);
      }
    }
  preferences.end();
  
  // The crystal load value needs to match in order to have an accurate calibration
  si5351.init(SI5351_CRYSTAL_LOAD_8PF, 0, 0);
  si5351.drive_strength(SI5351_CLK0, SI5351_DRIVE_2MA);
  si5351.drive_strength(SI5351_CLK1, SI5351_DRIVE_2MA);
  si5351.drive_strength(SI5351_CLK2, SI5351_DRIVE_2MA);

  SendFrequency(); // Set Si5351A output

  // Connect to Wi-Fi
  Serial.print("Connecting to ");
  Serial.println(ssid);
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println(" WiFi CONNECTED");
  Serial.print("IP Address: ");
  Serial.println(WiFi.localIP()); 

  timeClient.begin();
  timeClient.update();

  // Convert NTP epoch to a structure readable by RTClib
  unsigned long epochTime = timeClient.getEpochTime();
  DateTime ntpTime = DateTime(epochTime);

  // Update DS3231
  rtc.adjust(ntpTime);
  Serial.println("DS3231 successfully set from NTP!");
  // Disconnect Wi-Fi after setting to save power (optional)
  WiFi.disconnect(true);
  WiFi.mode(WIFI_OFF);
  Serial.println("WiFi DISCONNECTED");
}


/*
 *  Monitor buttons and update display
 */
void loop(void)
{
  rBalance(val);
  lBalance(val);
  val++;
  // Display process
  for (int yoff = 0; yoff < lcd.height(); yoff += sprite_height)
  {
    sprites[flip].clear(BGCol);

    // Draw dial
    dial.draw(Dial_frq, yoff);

    // Draw digital frequency display
    char str[12], strl[24];
    sprintf(str, "%3d.%03d.%02d%1d",  Dial_frq/1000000, (Dial_frq/1000)%1000, (Dial_frq/10)%100, Dial_frq%10 );
    int cc=0;
    if(str[0]=='0'){
      cc++;
      if(str[1]=='0') cc++;
    }
    for(int i=0; i<12; i++){
      strl[2*i]=str[i+cc];
      strl[2*i+1]=' ';
    }
    #ifdef MODE0
    int xdf=0, ydf=0;// position
    int hdf = top_position+40;
    sprites[flip].drawRoundRect(xdf+80.0, ydf+190 -yoff, lcd.width()-160, hdf, 10, TFT_SKYBLUE);
    sprites[flip].setTextColor(TFT_SKYBLUE);
    sprites[flip].setCursor(xdf + 0.04f*lcd.width() + cc*sprites[flip].textWidth("0 "), ydf + 0.5f*(hdf - sprites[flip].fontHeight()) -yoff);
    #endif
    // Display frequency
    sprites[flip].setFont(&fonts::DejaVu24);
    sprites[flip].setTextSize(1.0f);
    sprites[flip].setCursor(78.0, 198 -yoff);  //  "-yoff" is Required
    sprites[flip].print(str);
    // Display "BAND LOCK" if Limit = true & not VFO-520 band
    sprites[flip].setFont(&fonts::DejaVu12);  // Band lock
    sprites[flip].setTextSize(1.0f);
    sprites[flip].setTextColor(TFT_GOLD);
    sprites[flip].setCursor(121, 120 -yoff);  //  "-yoff" is Required
    if ( (Limit) )//& (activeBand != 9) )
      sprites[flip].print("BAND LOCK");

    // Display STEP size
    int Xoffset, Yoffset;
    if (cnt == 0) Xoffset = 0;
    if (cnt == 1) Xoffset = 5;
    if (cnt == 2) Xoffset = 10;
    if (cnt == 3) Xoffset = 15;
    if (cnt == 4) Xoffset = 20;

    sprites[flip].setCursor(180 -Xoffset, 136 -yoff);  // Step
    sprites[flip].print(incrList[cnt]);
    sprites[flip].setCursor(133.4 -Xoffset, 136 -yoff);  //  "-yoff" is Required
    sprites[flip].print("STEP:");

    // Display "VFO 520" if AciveBand = 9
    if( activeBand == 9) {
      sprites[flip].setCursor((240/2)+7, 168-yoff);  //  "-yoff" is Required
      sprites[flip].print("VFO 520");
    }

    // Read and print time
    if (rtc_found) // If RTC is found, show time
    {
      DateTime now = rtc.now();
      sprites[flip].setCursor((240/2)-10, 154.0-yoff); //  "-yoff" is Required
      sprintf(buffer, "%02d:%02d:%02d UTC", now.hour(), now.minute(), now.second());
      sprites[flip].print(buffer);
    }
    sprites[flip].pushSprite(&lcd, 0, yoff);
    flip = !flip;
  }// End of Display process
} // End of loop()


/*
 *	Non-blocking delay function:
 */
void Delay ( uint32_t timeOut )
{
	uint32_t t0 = millis ();
	while (( millis () - t0 ) < timeOut ) {}
}

/*
 * I/Q balance voltage
 */
void rBalance(int val) {
  int rval = val;
  dacWrite(RBAL_PIN, rval);
}

/*
 * I/Q balance voltage
 */
void lBalance(int val) {
  int lval = val;
  dacWrite(LBAL_PIN, lval);
}


/*--------------------------------------------------------------------------
         Kenwood TS-2000 CAT control emulation 9600 baud
---------------------------------------------------------------------------*/
void CAT_control(void) {
  received = Serial.readString();
  received.toUpperCase();
  received.replace("\n","");

  pinMode(TX, OUTPUT); //TX output control signal, TX high; RX LOW

  // Find out which band Dial_frq is in
  for(int i=0;i<10;i++)
    {
    if ((Dial_frq >= bandData[i].lowLimit) && (Dial_frq <= bandData[i].topLimit))
      {
        mem = i;
        mem_old = i;
        activeBand = i;
        //Serial.print("\nactiveBand ");Serial.println(activeBand);
      }
    }

  String data = "";
  int bufferIndex = 0;

  for (int i = 0; i < received.length(); ++i)
    {
      char c = received[i];
      if (c != ';')
        {
          data += c;
        }
      else
        {
          if (bufferIndex == 0)
            {
            data += '\0';
            receivedPart1 = data;
            bufferIndex++;
            data = "";
            }
          else
            {
              data += '\0';
              receivedPart2 = data;
              bufferIndex++;
              data = "";
            }
        }
    }

  command = receivedPart1.substring(0,2);
  command2 = receivedPart2.substring(0,2);
  parameter = receivedPart1.substring(2,receivedPart1.length());
  parameter2 = receivedPart2.substring(2,receivedPart2.length());

  if (command == "FA")
    {
      if (parameter != "")
        {
          Dial_frq = parameter.toInt();
          f_fchange = 1;   // display needs to be updated
          SendFrequency();
        }
      sent = "FA" // Return 11 digit frequency in Hz.
      + String("00000000000").substring(0,11-(String(Dial_frq).length()))
      + String(Dial_frq) + ";";
    }
  else if (command == "PS")
    {
      sent = "PS1;";
    }
  else if (command == "TX")
    {
      sent = "TX0;";
      digitalWrite(TX, HIGH);
      Serial.print("TX0 ");Serial.println(digitalRead(TX));
      TxStatus = 1;
    }
  else if (command == "RX")
    {
      sent = "RX0;";
      digitalWrite(TX, LOW);
      Serial.print("RX0 ");Serial.println(digitalRead(TX));
      TxStatus = 0;
    }
  else  if (command == "ID")
    {
      sent = "ID019;";
    }
  else if (command == "AI")
    {
      sent = "AI0;";
    }
  else if (command == "IF")
    {
      CAT_mode = bandData[activeBand].opMode;

      if (TxStatus == 1)
        {
          sent = "IF" // Return 11 digit frequency in Hz.
          + String("00000000000").substring(0,11-(String(Dial_frq).length()))
          + String(Dial_frq) + "00000" + "+" + "0000" + "0" + "0" + "0" + "00" + "1" + String(CAT_mode) + "0" + "0" + "0" + "0" + "000" + ";";
        }
      else
        {
          sent = "IF" // Return 11 digit frequency in Hz.
          + String("00000000000").substring(0,11-(String(Dial_frq).length()))
          + String(Dial_frq) + "00000" + "+" + "0000" + "0" + "0" + "0" + "00" + "0" + String(CAT_mode) + "0" + "0" + "0" + "0" + "000" + ";";
        }
    }
  else if (command == "MD")
    {
      CAT_mode = bandData[activeBand].opMode;
      //Serial.print("CAT_mode ");Serial.println(CAT_mode);
      sent = "MD" + String(CAT_mode) + ";";
    }

  if (command2 == "ID")
    {
      sent2 = "ID019;";
    }

  if (bufferIndex == 2)
    {
      Serial.print(sent2);
    }
  else
    {
      Serial.print(sent);
    }

  if ((command == "RX") || (command = "TX")) Delay(50);

  sent = String("");
  sent2 = String("");
  Serial.flush();          
}


/*
 *	"task0()" running on core #0. Its primary role
 *	is to handle the frequency encoder and update Si5351 clock generator.
 */
void task0 ( void* arg )
{
  pinMode(LED_BUILTIN, OUTPUT);
  pinMode(TX, OUTPUT);
  pinMode(PTT_PIN, INPUT_PULLUP);

	while ( true )  // Runs forever (like "loop")
	  {
      if (Serial.available() > 0)
        {
          cat_stat = 1;
          Serial.print("\ncat_stat ");Serial.println(cat_stat);
          CAT_control();
        }
      if(cat_stat == 0)
        {
          // Encoder
          newPosition = encoder.getCount() / 2;
          // Update frequency
          step = incrList[cnt];
          newPosition = encoder.getCount() / 2;
          if (oldPosition != newPosition)
            {
              //Serial.println(newPosition);
              Dial_frq += step * newPosition;
              if(Dial_frq > fmax) Dial_frq = fmax;
              if(Dial_frq < fmin) Dial_frq = fmin;
              f_fchange = 1; 
              oldPosition = newPosition;
              encoder.clearCount();

              if (Limit) // Stay within HAM band true
                {
                  if (Dial_frq > bandData[mem].topLimit )		// Range checks
				              Dial_frq = bandData[mem].topLimit;
			            if (Dial_frq < bandData[mem].lowLimit )
				              Dial_frq = bandData[mem].lowLimit;
                }
              }
              // Send frequency to Si5351A 
              if(f_fchange==1){
                f_fchange=0;
                // Lo freq
                SendFrequency();
              }
  	      delay(1);  //prevents a watchdog task timeout-reboot loop
        }
      delay(1);  //prevents a watchdog task timeout-reboot loop
    }
}

